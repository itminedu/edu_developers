#!/bin/sh

apt-get -y install oracle-java8-installer
